<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('contact-form', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('email')->unique();
            $table->string('name');
            $table->string('text');
            $table->string('created_at');
            $table->ipAddress('visiteur');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
         Schema::drop('contact-form');
    }
};

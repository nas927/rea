var app = angular.module("actu", ['ngAnimate', 'ngCookies']);

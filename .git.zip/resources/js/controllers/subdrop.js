var app = angular.module("subdrop", ['ngAnimate', 'ngCookies']);

var app = angular.module("politique", ['ngAnimate', 'ngCookies']);

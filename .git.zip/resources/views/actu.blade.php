@extends('template.features')
@section('css')
<link rel="stylesheet" href="{{ minify('css/actu.css') }}" >
@endsection
@section('app', 'actu')
@section('main')
	<strong>Blabla</strong>
@endsection
@section('js', 'actu')